#include <iostream>
#include <fstream>
#include <string>

#include "arena.h";

using namespace std;

int main()
{
    mainMenu();

    return 0;
}
