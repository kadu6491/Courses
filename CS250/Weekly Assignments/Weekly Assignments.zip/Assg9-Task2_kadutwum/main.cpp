#include <iostream>
#include "fractionType.h";

using namespace std;

int main()
{
    fractionType num1(1, 3);                        //Line 1
    fractionType num2;                              //Line 2
    fractionType num3;
    return 0;
}
